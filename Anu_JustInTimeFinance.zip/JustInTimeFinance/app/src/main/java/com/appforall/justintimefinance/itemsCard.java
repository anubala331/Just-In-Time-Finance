package com.appforall.justintimefinance;

public class itemsCard {

    private String accountNumberCard, bankTypeCard;




    public String getAccountNumberCard() {
        return accountNumberCard;
    }

    public void setAccountNumberCard(String accountNumberCard) {
        this.accountNumberCard = accountNumberCard;
    }

    public String getBankTypeCard() {
        return bankTypeCard;
    }

    public void setBankTypeCard(String bankTypeCard) {
        this.bankTypeCard = bankTypeCard;
    }
}
